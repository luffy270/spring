package com.bingo.springcloudeurekaconfig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudEurekaConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudEurekaConfigApplication.class, args);
	}
}
